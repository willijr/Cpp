#include <cmath>
#include <iomanip>
#include "personBMI.h"
#include "ranges.h"

using namespace std;

void personBMI::print() const
{
	cout << fixed << setprecision(1);
	string result;
    cout << "'s BMI is: " << calculateBMI();
        
	if (calculateBMI() < 18.5)
		result = "Underweight.";
	else if (calculateBMI() > 18.5 && calculateBMI() < 24.9)
		result = "Healthy.";
	else if (calculateBMI() > 25 && calculateBMI() < 29.9)
		result = "Overweight.";
	else
		result = "Obese.";
	cout << ", which is considered: " << result << endl << endl;
}

//calculates and returns the BMI of the person
double personBMI::calculateBMI() const
{
    return (weight / pow (heightI, 2) * 703);
}

//assings the persons name (from personType) and weight
void personBMI::setNameHeightWeight(string first, 
                        string last, int h, int w)
{
    personType::setName(first, last);

    heightI = h;
    weight = w;
}

bool personBMI::operator==(const personBMI& otherPerson) const
{
    return (calculateBMI() == otherPerson.calculateBMI());
}

bool personBMI::operator>(const personBMI& otherPerson) const
{
    return (calculateBMI() > otherPerson.calculateBMI());
}

bool personBMI::operator<(const personBMI& otherPerson) const
{
    return (calculateBMI() < otherPerson.calculateBMI());
}

ostream& operator << (ostream& osObject, const personBMI& BMI)
{
    osObject << BMI.first << " " << BMI.last;

    return osObject;
}

istream& operator >> (istream& isObject, 
                      personBMI& BMI)
{  
	bool done = false;
	do
	{
		try
		{
			cout << "Please enter your first and last name: ";					
			isObject >> BMI.first >> BMI.last;		
										
			cout << endl << "Please enter your height in feet and inches: ";
			isObject >> BMI.heightF >> BMI.heightI;		
							
			BMI.heightI = (BMI.heightF * 12) + BMI.heightI;	
			
    		if (BMI.heightI < 30 || BMI.heightI > 120 || !cin)				//setting the ranges of height in inches
    		    throw ranges("Height");										//ranges function with string of Height
								
			cout << "Please enter your weight in lbs: ";					
			isObject >> BMI.weight;		
			
    		if (BMI.weight < 40 || BMI.weight > 700 || !cin)				//setting the ranges of weight
    		    throw ranges("Weight");										//ranges funtion with string of Weight
													
			system("CLS");			
	    		
			done = true;									
    		return isObject;
    	}
    	catch (ranges obj)													//catching using the ranges class named obj
    	{
    	    cout << obj.what() << endl << endl;     						//displaying the ranges function what()
		}
	}
	while (!done);
}

//Constructor 
personBMI::personBMI(string first, string last, int h, int w) : personType(first, last) 
{	
    if (h >= 0)
        heightI = h;
    else
        heightI = 0;

    if (w >= 0)
        weight = w;
    else
        weight = 0;
}

#ifndef EXCEPTION_H
#define EXCEPTION_H
#include <iostream>
#include <string>

using namespace std;

class ranges
{ 
public: 
    ranges()
    {
        message = "Number is outside the normal range.";
    } 

    ranges(string str)
    {
        system ("CLS");
		message = str + " is uncommon. Please try again.";
    } 

    string what()
    {
        return message;
    }

private:
    string message;
};

#endif

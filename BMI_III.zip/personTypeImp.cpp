//personTypeImp.cpp

#include <iostream>  
#include <string> 
#include "personType.h"
  
using namespace std;

//displays the first and last name
void personType::print() const
{
    cout << firstName << " " << lastName;
}

//assigns the first and last name
void personType::setName(string first, string last)
{
    firstName = first;
    lastName = last;
}

//returns the first name
string personType::getFirstName() const
{
    return firstName;
}

//returns the last name
string personType::getLastName() const
{
    return lastName;
}

//constructor
personType::personType(string first, string last) 
{ 
    firstName = first;
    lastName = last;
}


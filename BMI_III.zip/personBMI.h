#ifndef personBMI_h
#define personBMI_h

#include "personType.h"

class personBMI: public personType
{
	
      //Overload the stream insertion and extraction operators
    friend ostream& operator << (ostream&, const personBMI &);
    friend istream& operator >> (istream&, personBMI &);
		
public:
    void print() const;
       //Function to output the normal range of BMI,
       //name, and the BMI of the person

    double calculateBMI() const; 
      //Function to calculate and return the BMI.
      //Postcondition: BMI is calculated and returned
      
    void setNameHeightWeight(string first, string last, int h, int w);
      //Function to set the first name, last name, height, and weight to the parameters.
      //Postcondition: firstName = first; lastName = last; height = h; weight = w
      
    bool operator==(const personBMI& otherPerson) const;
      //Overload the operator ==      
      
    bool operator>(const personBMI& otherPerson) const;
      //Overload the operator >
	  
    bool operator<(const personBMI& otherPerson) const;
      //Overload the operator <	        
      
    personBMI(string first = "", string last = "", 
                     int h = 0, int w = 0);
      //Constructor with parameters
      //Sets the first name, last name, height, and weight according to the parameters. 
	  //If no value is specified, the default values are assumed.
      //Postcondition: firstName = first; lastName = last; height = h; weight = w     
      
private:
    int height;     //variable to store the pay rate
    int weight;     //variable to store the hours worked
    
	string first, last;													//assigns the strings for the main 
	int heightF, heightI;										//assigns the ints for the main    
};

#endif

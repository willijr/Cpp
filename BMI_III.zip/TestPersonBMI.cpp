#include <iostream>				//for input and output
#include "personBMI.h"			//usinng class personBMI.h
  
using namespace std; 
   
int main()
{	
	personBMI person, otherPerson;										//assigns person and otherPerson using the class personBMI
	
	cin >> person;														//using the overloaded stream extraction to input for person
	cin >> otherPerson;													//using the overloaded stream extraction to input for otherPerson
				
	person.calculateBMI();												//runs the function to calculate BMI for person
	otherPerson.calculateBMI();											//runs the function to calculate BMI for otherPerson
	
	cout << "A BMI under 18.5 is considered underweight.\n" <<			//displays ranges of BMI
			"A BMI of 18.5 to 24.9 is considered healthy.\n" <<			//displays ranges of BMI
			"A BMI of 25.0 to 29.9 is considered overweight.\n" <<		//displays ranges of BMI
			"A BMI over 30.0 is considered obese.\n\n";					//displays ranges of BMI
	
	cout << person;														//using the overloaded stream insertion to display the name of person
    person.print();														//displays person results using the print function
    cout << otherPerson;												//using the overloaded stream insertion to display the name of otherPerson
    otherPerson.print();												//displays otherPerson results using the print function
    
    if (person < otherPerson)											//using the overloaded less than operator
    	cout << "The lower BMI is: " << person << endl;					//using the overloaded stream insertion to display the name of person
    else if (person > otherPerson)
    	cout << "The lower BMI is: " << otherPerson << endl;			//using the overloaded stream insertion to display the name of otherPerson
	 
	if (person == otherPerson)											//using the overloaded equal to operator
		cout << "The BMI is equal for " << person 						//using the overloaded stream insertion to display the name of person
			 << " and " << otherPerson << endl;							//using the overloaded stream insertion to display the name of otherPerson}

    return 0;															//ending the program
}
